function changeToLogout(logInBotton){
    logInBotton.innerText="Logout";
}

function removeAddButton(addButton){
    addButton.remove();
}